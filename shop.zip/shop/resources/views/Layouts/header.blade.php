<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />


    <title>山东省瑞丹堂电子商务有限公司</title>
    <meta name="Keywords" content="山东省瑞丹堂电子商务有限公司" />
    <meta name="Description" content="山东省瑞丹堂电子商务有限公司" />


    <link href="/index/css/style.css" type="text/css" rel="stylesheet">
    <script type="text/javascript" src="/index/js/-jquery-1.8.3.min.js"></script>
    <link href="/index/css/nav2.css" type="text/css" rel="stylesheet"><!--藏品分类 -->
    <link href="/index/css/amazeui.min.css" rel="stylesheet" />
    <script src="/index/js/amazeui.min.js"></script>
    <!--手滑效果 -->
    <script type="text/javascript">
        <!--
        var timeout         = 500;
        var closetimer		= 0;
        var ddmenuitem      = 0;

        // open hidden layer
        function mopen(id)
        {
            // cancel close timer
            mcancelclosetime();

            // close old layer
            if(ddmenuitem) ddmenuitem.style.visibility = 'hidden';

            // get new layer and show it
            ddmenuitem = document.getElementById(id);
            ddmenuitem.style.visibility = 'visible';

        }
        // close showed layer
        function mclose()
        {
            if(ddmenuitem) ddmenuitem.style.visibility = 'hidden';
        }

        // go close timer
        function mclosetime()
        {
            closetimer = window.setTimeout(mclose, timeout);
        }

        // cancel close timer
        function mcancelclosetime()
        {
            if(closetimer)
            {
                window.clearTimeout(closetimer);
                closetimer = null;
            }
        }

        // close layer when click-out
        document.onclick = mclose;
        // -->
    </script>
</head>
